package com.rest;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

public class PolicyDTO implements Serializable {
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String policyNumber;
	
	private String DOB;
	
	private String expiryDate;
	
	public String getPolicyNumber() {
		return policyNumber;
	}
	@XmlElement 
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getDOB() {
		return DOB;
	}
	@XmlElement 
	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getExpiryDate() {
		return expiryDate;
	}
	@XmlElement 
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public PolicyDTO(String a, String b, String c)
	{
		this.policyNumber=a;
		this.DOB = b;
		this.expiryDate=c;
	}

	

}
