package com.rest;  

import java.io.Serializable;  
import javax.xml.bind.annotation.XmlElement; 
import javax.xml.bind.annotation.XmlRootElement; 
@XmlRootElement(name = "user") 

public class User1 implements Serializable {  
   private static final long serialVersionUID = 1L; 
   private String name;
	
   private int age;
	
	private String sex;
	
	private PolicyDTO policyDTO;
   public PolicyDTO getPolicyDTO() {
		return policyDTO;
	}
   @XmlElement(name = "policy")
	public void setPolicyDTO(PolicyDTO policyDTO) {
		this.policyDTO = policyDTO;
	}

public User1(){} 
    
   public User1(String id, int name, String sex, PolicyDTO p1){  
      this.name = id; 
      this.age = name; 
      this.sex = sex; 
      this.policyDTO=p1;
   }  
   public String getName() {
		return name;
	}
   
	@XmlElement 
	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}
	@XmlElement 
	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}
	@XmlElement 
	public void setSex(String sex) {
		this.sex = sex;
	}
} 