package com.rest;  

import java.util.ArrayList; 
import java.util.List;  

public class UserDao { 
   public List<User> getAllUsers(){ 
      
      List<User> userList = null; 
      try { 
          
        	User user = new User(1, "Mahesh", "Teacher"); 
        	User user1 = new User(2, "Vicknesh", "Father");
            userList = new ArrayList<User>(); 
            userList.add(user); 
            userList.add(user1);
             
          
        
      } catch (Exception e) { 
         e.printStackTrace(); 
      }  
      return userList; 
   } 
 /*  private void saveUserList(List<User> userList){ 
      try { 
         File file = new File("Users.dat"); 
         FileOutputStream fos;  
         fos = new FileOutputStream(file); 
         ObjectOutputStream oos = new ObjectOutputStream(fos); 
         oos.writeObject(userList); 
         oos.close(); 
      } catch (FileNotFoundException e) { 
         e.printStackTrace(); 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } 
   } */   
}