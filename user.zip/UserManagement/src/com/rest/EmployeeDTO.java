package com.rest;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "employee") 

public class EmployeeDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
	
    private int age;
	
	private String sex;
	
	private PolicyDTO policyDTO;
	
	public String getName() {
		return name;
	}
	@XmlElement 
	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}
	@XmlElement 
	public void setAge(int age) {
		this.age = age;
	}

	public String getSex() {
		return sex;
	}
	@XmlElement 
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public PolicyDTO getPolicyDTO() {
		return policyDTO;
	}
	@XmlElement 
	public void setPolicyDTO(PolicyDTO policyDTO) {
		this.policyDTO = policyDTO;
	}
	
	public EmployeeDTO(String a, int b, String c)
	{
		this.name = a;
		this.age = b;
		this.sex = c;
	}
	
	public EmployeeDTO(String a, int b, String c, PolicyDTO d)
	{
		this.name = a;
		this.age = b;
		this.sex = c;
		this.policyDTO = d;
	}

}
