package com.rest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/PolicyService") 

public class PolicyService {  
   PolicyDAO policyDAO = new PolicyDAO();  
   @GET 
   @Path("/policies") 
   @Produces(MediaType.APPLICATION_XML) 
   public List<EmployeeDTO> getUsers(){ 
	   System.out.println("1st Element " + policyDAO.getEmployeeDetails().get(0));
	  return policyDAO.getEmployeeDetails(); 
   }  
}