package com.rest;

import java.util.ArrayList;
import java.util.List;

public class PolicyDAO {
	
	public List<EmployeeDTO> getEmployeeDetails()
	{
		List<EmployeeDTO> employeeList = new ArrayList<EmployeeDTO>();
		try {
			System.out.println("Inside Try");
			PolicyDTO p1 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	EmployeeDTO e1 = new EmployeeDTO("Alan", 65 , "M");
	    	 employeeList.add(e1);
	    	PolicyDTO p2 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	EmployeeDTO e2 = new EmployeeDTO("Bunny", 65 , "M");
	    	PolicyDTO p3 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	EmployeeDTO e3 = new EmployeeDTO("Celine", 40 , "f");
	    	PolicyDTO p4 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	EmployeeDTO e4 = new EmployeeDTO("Dhoni", 48 , "M" );
	       
	        employeeList.add(e2);
	        employeeList.add(e3);
	        employeeList.add(e4);
	        
	        
	       }
	     catch (Exception e) 
	     { 
	       e.printStackTrace(); 
	     }  
	    return employeeList; 
	}
     
 
}
