package com.rest;  

import java.util.ArrayList; 
import java.util.List;  

public class UserDAO1 { 
	public List<User1> getEmployeeDetails()
	{
		List<User1> employeeList = new ArrayList<User1>();
		try {
			System.out.println("Inside Try");
			PolicyDTO p1 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
			User1 e1 = new User1("Alan", 65 , "M", p1);
	    	 employeeList.add(e1);
	    	PolicyDTO p2 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	User1 e2 = new User1("Bunny", 65 , "M", p2);
	    	PolicyDTO p3 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	User1 e3 = new User1("Celine", 40 , "f", p3);
	    	PolicyDTO p4 = new PolicyDTO("01PH24578", "24/11/1948","24/11/2018" );
	    	User1 e4 = new User1("Dhoni", 48 , "M" , p4);
	       
	        employeeList.add(e2);
	        employeeList.add(e3);
	        employeeList.add(e4);
	        
	        
	       }
	     catch (Exception e) 
	     { 
	       e.printStackTrace(); 
	     }  
	    return employeeList; 
	}
 /*  private void saveUserList(List<User> userList){ 
      try { 
         File file = new File("Users.dat"); 
         FileOutputStream fos;  
         fos = new FileOutputStream(file); 
         ObjectOutputStream oos = new ObjectOutputStream(fos); 
         oos.writeObject(userList); 
         oos.close(); 
      } catch (FileNotFoundException e) { 
         e.printStackTrace(); 
      } catch (IOException e) { 
         e.printStackTrace(); 
      } 
   } */   
}