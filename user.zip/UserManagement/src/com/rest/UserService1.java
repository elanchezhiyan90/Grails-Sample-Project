package com.rest;

import java.util.List; 
import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType;  
@Path("/UserService1") 

public class UserService1 {  
   UserDAO1 userDao = new UserDAO1();  
   PolicyDAO pol = new PolicyDAO();
   @GET 
   @Path("/users1") 
   @Produces(MediaType.APPLICATION_XML) 
   public List<User1> getUsers(){ 
      return userDao.getEmployeeDetails(); 
   }  
}